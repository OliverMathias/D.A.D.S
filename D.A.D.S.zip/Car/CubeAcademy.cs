﻿using MLAgents;

public class CubeAcademy : Academy { }