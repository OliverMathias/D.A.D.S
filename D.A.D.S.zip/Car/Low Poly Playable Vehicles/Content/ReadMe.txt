This pack contains 4 playable vehicles with separate brake lights and wheels and car interior.

* Sedan
	Vertices - 7262
	Triangles - 3903
* Sports
	Vertices - 11171
	Triangles - 6343 		
* Utility Vehicle
	Vertices - 12699
	Triangles - 7342  	
* Bus
	Vertices - 13407
	Triangles - 8705

A Single Texture Atlas of size 512px.

This pack also contains 2 game props.

* Low Poly Tree

* Low Poly Road