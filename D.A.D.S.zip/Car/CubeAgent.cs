﻿using System.Collections.Generic;
using UnityEngine;
using MLAgents;
using static System.Math;
using System.Linq;

public class CubeAgent : Agent
{
    Rigidbody rBody;
    private RayPerception m_RayPer;
    private GameObject[] obstacles;
    public GameObject Arena;
    GameObject[] arenaObstacles = new GameObject[80];
    void Start()
    {
        rBody = GetComponent<Rigidbody>();
        m_RayPer = GetComponent<RayPerception>();

        arenaObstacles = Arena.transform.Cast<Transform>().Where(c => c.gameObject.tag == "obstacle").Select(c => c.gameObject).ToArray();

    }

    public Transform Target;
    private static float initialDistance;
    public GameObject obstaclePrefab;
    private GameObject[] offList;
    public System.Random rand = new System.Random();
    public override void AgentReset()
    {
        //turn off car so it doesn't trigger anything
        foreach (var c in this.GetComponentsInChildren<Collider>())
        {
            if (c.isTrigger) c.enabled = false;
        }

        //turn obstacles on
        for (int i = 0; i < arenaObstacles.Length; i++)
        {
            arenaObstacles[i].SetActive(true);
           // Debug.Log("on");
        }

        //previous was 160, now 100, so we can have more blocks
        var randomObjects = new GameObject[100];
        for (int i = 0; i < 100; i++)
        {
            var index = rand.Next(arenaObstacles.Length);

            randomObjects[i] = arenaObstacles[index];
        }

        //turn list off
        for (int i = 0; i < randomObjects.Length; i++)
        {
            randomObjects[i].SetActive(false);
            //Debug.Log("off");
        }

        //move target to an empty obstacle location
        //Target.position = randomObjects[0].transform.position;
        Target.localPosition = new Vector3(0f, 0.11f, 4.16f);
        Target.transform.rotation = Quaternion.Euler(new Vector3(0, 0, 0));


        //move car to an empty obstacle location
        foreach (var c in this.GetComponentsInChildren<Collider>())
        {
            if (c.isTrigger) c.enabled = true;
        }

        this.rBody.angularVelocity = Vector3.zero;
        this.rBody.velocity = Vector3.zero;
        //this.transform.position = randomObjects[1].transform.position;
        this.transform.localPosition = new Vector3(0f, 0.11f, 0f);
        this.transform.rotation = Quaternion.Euler(new Vector3(0, 0, 0));

    }   

    private bool wallCrash;
    private bool targetHit;
    void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.tag == "wall" || collision.gameObject.tag == "obstacle")
        {
            wallCrash = true;
        }

        if (collision.gameObject.tag == "target")
        {
            targetHit = true;
        }
    }


    float getDistance()
    {
        return Vector3.Distance(this.transform.position, Target.position);
    }

    public static float Sigmoid(float value)
    {
        return 1.0f / (1.0f + (float)System.Math.Exp(-value));
    }

    public override void CollectObservations()
    {
        //raycast obs
        const float rayDistance = 15f;
        //full round radar
        float[]  rayAngles = {0f, 30f, 60f, 90f, 120f, 150f, 180f, 210f, 240f, 270f, 300f, 330f};
        string[] detectableObjects = { "wall", "target", "obstacle" };
        AddVectorObs(m_RayPer.Perceive(rayDistance, rayAngles, detectableObjects, 0f, 0f));

        //Agent positions, distance to target and rotations
        AddVectorObs(gameObject.GetComponent<LPPV_CarController>().CurrentSpeed);

        AddVectorObs(this.transform.rotation.eulerAngles.x);
        AddVectorObs(this.transform.rotation.eulerAngles.z);

        //get agent and car positions
        //AddVectorObs(this.transform.position);
        //AddVectorObs(Target.transform.position);
        //get distance only
        AddVectorObs(getDistance());


    }

    private float startDifference = 0;
    public override void AgentAction(float[] vectorAction, string textAction)
    {
        // Actions, size = 2
        Vector3 controlSignal = Vector3.zero;
        float turn = vectorAction[0];
        float forward = vectorAction[1];

        //punish the car for expending energy so it finishes this shit faster
        //float summedActions = System.Math.Abs(turn) + System.Math.Abs(forward);
        //only punish going forward so it can turn easily 
        //float summedActions = System.Math.Abs(forward);
        //SetReward(-0.005f * (summedActions / 2));

        SetReward(-0.0005f);

        //pass the control signals to the car script
        gameObject.GetComponent<LPPV_CarController>().motorFloat = forward;
        gameObject.GetComponent<LPPV_CarController>().steeringFloat = turn;
        //rBody.AddForce(controlSignal * speed);

        // get current distance to target, and diff btwn current and start distance
        float distanceToTarget = getDistance();
        float startDifference = initialDistance - distanceToTarget;

        // Reached target
        if (targetHit)
        {
            SetReward(1.0f);
            targetHit = false;
            Debug.Log("yay");
            Done();
        }

        if (wallCrash)
        {
            SetReward(-1.0f);
            wallCrash = false;
            Debug.Log("poop");
            Done();
        }

    }

    public override float[] Heuristic()
    {
        var action = new float[2];
        action[0] = Input.GetAxis("Horizontal");
        action[1] = Input.GetAxis("Vertical");
        return action;
    }
}